cd checkpoints
wget http://virtual-home.org/release/watch_and_help/checkpoints.zip
unzip checkpoints.zip
mv checkpoints/* .
rm checkpoints.zip
rmdir checkpoints
