import pickle
from tqdm import tqdm
#file = open("../test_results/alice_hp_results/results_2.pik",'rb')
file = open("../test_results/multiBob_env_task_set_10_hrl_truegoal/results_0.pik",'rb')
#file = open("../test_results/alice_hp_results/results_42.pik", 'rb')
data = pickle.load(file)
for i, (k,v) in enumerate(data.items()):
    print((k,v))

'''dataset_path = './dataset/test_env_set_help.pik'
env_task_set = pickle.load(open(dataset_path, 'rb'))
record_dir = '../test_results/multiBob_env_task_set_20_hybrid_predgoal'

episode_ids = list(range(len(env_task_set)))
episode_ids = sorted(episode_ids)
num_tries = 5
S = [[] for _ in range(len(episode_ids))]
L = [[] for _ in range(len(episode_ids))]
test_results = {}
for iter_id in range(num_tries):
    seed = iter_id
    for episode_id in tqdm(range(len(episode_ids))):
        log_file_name = record_dir + '/logs_agent_{}_{}_{}.pik'.format(env_task_set[episode_id]['task_id'],
                                                                       env_task_set[episode_id]['task_name'],
                                                                       seed)
        if True:
            file = open(log_file_name, 'rb')
            data = pickle.load(file)
            S[episode_id].append(data['finished'])
            L[episode_id].append(data['L'])
            test_results[episode_id] = {'S':S[episode_id],
                                        'L':L[episode_id]}
            
test_results[episode_id] = {'S':S[episode_id], 'L':L[episode_id]}
pickle.dump(test_results, open(record_dir + '/results_{}.pik'.format(0), 'wb'))'''