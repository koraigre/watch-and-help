import matplotlib.pyplot as plt
from matplotlib.pyplot import MultipleLocator
from brokenaxes import brokenaxes
import json
import numpy as np

def paint_ori_bax():
    with open('./results_mcts_across_seeds_all_baselines_reward.json', 'r') as fp:
        data = json.load(fp)

    name = ['Alice', 'HP$_{TG}$', 'HP', 'HP$_{RG}$', 'Random Action', 'Hybrid$_{TG}$', 'Hybrid',
            'Oracle$^{B}$', 'Oracle$^{A,B}$']   
    sr = []
    su = []
    x_error = []
    y_error = []
    colors = ['darkolivegreen', 'purple', 'red', 'green', 'orange', 'deeppink', 'brown', 'blue', 'aqua']
    for val in data['S'].values():
        sr.append(np.mean(val[0]))
        x_error.append(np.mean(val[1]))
        
    base_speed = np.mean(data['L']["../test_results/alice_hp_results"][0])

    for val in data['L'].values():
        su.append(base_speed / np.mean(val[0]) - 1)
        y_error.append(base_speed / np.mean(val[0]) - base_speed / (np.mean(val[0]) + np.mean(val[1])))

    bax = brokenaxes(xlims=((0.60, 1.02),), ylims=((-0.3, 0.7),(0.9,1.3),(1.5,2.05)), hspace=0.05)

    for i in range(len(sr)):
        bax.errorbar(sr[i], su[i], xerr=x_error[i], yerr=y_error[i], fmt='o', color = colors[i], capsize=2)

    #bax.set_xticks([0.60,0.65,0.70,0.75,0.80,0.85,0.90,0.95,1.00])
    #bax.set_yticks([-0.2,0.0,0.2,0.4], which='lower')

    bax.set_xlabel("Success Rate")
    bax.set_ylabel("Speed Up")
    #bax.scatter(sr, su, c=['darkolivegreen', 'purple', 'red', 'green', 'orange', 'pink', 'brown', 'blue', 'aqua'])
    for i in range(len(sr)):
        if i == 5:
            bax.text(sr[i]-0.05, su[i]-0.05, name[i])
        elif i == 2:
            bax.text(sr[i]-0.02, su[i]+0.01, name[i])
        else:
            bax.text(sr[i], su[i]+0.01, name[i])
        
    bax.grid()
    #plt.savefig("ori.png")
    plt.savefig("ori.pdf", format="pdf")

def paint_com_bax():
    with open('./new.json', 'r') as fp:
        data = json.load(fp)

    name = ['HP$_{TG}$', 'HP', 'HP$_{RG}$', 'Random Action', 'Hybrid$_{TG}$', 'Hybrid']   
    sr = []
    su = []
    x_error = []
    y_error = []
    colors = ['purple', 'red', 'green', 'orange', 'deeppink', 'brown']
    for val in data['S'].values():
        sr.append(np.mean(val[0]))
        x_error.append(np.mean(val[1]))
        
    #base_speed = np.mean(data['L']["../new_test_results/alice_hp_results"][0])
    base_speed = 116.592
    for val in data['L'].values():
        su.append(base_speed / np.mean(val[0]) - 1)
        y_error.append(base_speed / np.mean(val[0]) - base_speed / (np.mean(val[0]) + np.mean(val[1])))

    bax = brokenaxes(xlims=((0.55, 1.02),), ylims=((-0.35, 0.75),(0.9,1.3),(1.5,2.05)), hspace=0.05)

    for i in range(len(sr)):
        bax.errorbar(sr[i], su[i], xerr=x_error[i], yerr=y_error[i], fmt='o', color = colors[i], capsize=2)

    #bax.set_xticks([0.60,0.65,0.70,0.75,0.80,0.85,0.90,0.95,1.00])
    #bax.set_yticks([-0.2,0.0,0.2,0.4], which='lower')

    bax.set_xlabel("Success Rate")
    bax.set_ylabel("Speed Up")
    #bax.scatter(sr, su, c=['darkolivegreen', 'purple', 'red', 'green', 'orange', 'pink', 'brown', 'blue', 'aqua'])
    for i in range(len(sr)):
        if i == 6:
            bax.text(sr[i]-0.05, su[i]-0.05, name[i])
        elif i == 4:
            bax.text(sr[i]-0.04, su[i]-0.07, name[i])
        else:
            bax.text(sr[i], su[i]+0.01, name[i])
        
    bax.grid()
    #plt.savefig("ori.png")
    plt.savefig("com.pdf", format='pdf')
    
def paint_ori_reward():
    with open('./results_mcts_across_seeds_all_baselines_reward.json', 'r') as fp:
        data = json.load(fp)
        
    data = data["SWS"]
        
    #name = ['Alice', 'HP$_{TG}$', 'HP', 'HP$_{RG}$', 'Random Action', 'Hybrid$_{TG}$', 'Hybrid',
    #        'Oracle$^{B}$', 'Oracle$^{A,B}$']
    name = ['Alice', 'Random Action', 'HP$_{RG}$', 'HP', 'HP$_{TG}$', 'Hybrid', 'Hybrid$_{TG}$',
            'Oracle$^{B}$', 'Oracle$^{A,B}$']
    #colors = ['skyblue', 'orchid', 'salmon', 'mediumseagreen', 'sandybrown', 'hotpink', 'peru', 'khaki', 'darkturquoise']
    colors = ['skyblue', 'sandybrown', 'mediumseagreen', 'salmon', 'orchid', 'peru', 'hotpink', 'khaki', 'darkturquoise']
    classes = ['Set Table', 'Put Groceries', 'Set Meal', 'Wash Dishes', 'Read Book', 'Overall']
    
    #[mean, error]
    values = {"Set Table":[[],[]], "Put Groceries":[[],[]], "Set Meal":[[],[]], "Wash Dishes":[[],[]], "Read Book":[[],[]], "Overall":[[],[]]}
    for i in range(len(classes)):
        for val in data.values():
            values[classes[i]][0].append(val[0][i])
            values[classes[i]][1].append(val[1][i])
            
    x = np.arange(len(classes))
    fig, ax = plt.subplots(figsize=(10,4))
    ax.set_xticklabels([''] + classes)
    plt.ylim(-0.3,1.15)
    bars = []
    for i in range(len(name)):
        dt = [val[0][i] for val in values.values()]
        err = [val[1][i] for val in values.values()]
        #print(dt)
        #bars.append(plt.bar(x-0.2, dt, width=0.1))
        plt.bar(x+0.1*i-0.4, dt, width=0.085, color=colors[i], yerr=err, capsize=2, label=name[i])
        
    plt.grid()
    plt.legend(loc="upper center", ncol=5)
    plt.tight_layout()
    plt.savefig("ori_reward.pdf", format="pdf")
    
paint_com_bax()